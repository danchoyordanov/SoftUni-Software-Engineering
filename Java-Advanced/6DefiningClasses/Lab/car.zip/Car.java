public class Car {
    public String brand;
    public String model;
    public int horsePower;

    public Car(String brandParam, String modelParam, int horsePowerParam){
        brand = brandParam;
        model = modelParam;
        horsePower = horsePowerParam;
    }
}
